#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>

#define DHTPIN 19
#define DHTTYPE DHT22
#define LDRPIN 34
#define TIMEDHT 1000

float humidity, celsius, lightIntensity;
uint32_t timerDHT = TIMEDHT;
DHT dht(DHTPIN, DHTTYPE);
LiquidCrystal_I2C lcd(0x27, 16, 2); // Alamat I2C bisa berbeda (0x3F atau 0x27)

int displayState = 0; // Untuk menyimpan state tampilan LCD

// Fungsi untuk membaca suhu dan kelembapan
void getTemperature() {
  if ((millis() - timerDHT) > TIMEDHT) {
    timerDHT = millis();
    humidity = dht.readHumidity();
    celsius = dht.readTemperature();

    if (isnan(humidity) || isnan(celsius)) {
      Serial.println("Failed to read from DHT sensor!");
      return;
    }
  }
}

// Fungsi untuk membaca intensitas cahaya
void getLightIntensity() {
  int ldrValue = analogRead(LDRPIN);
  lightIntensity = map(ldrValue, 0, 4095, 0, 100); // Konversi ke persen
}

void setup() {
  Serial.begin(115200);
  Serial.println("ESP32 dengan DHT22 dan LDR");

  dht.begin();
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Initializing...");
  delay(2000);
}

void loop() {
  getTemperature();
  getLightIntensity();

  // Menampilkan data ke Serial Monitor
  Serial.print("Temp: ");
  Serial.print(celsius);
  Serial.print(" C, Humidity: ");
  Serial.print(humidity);
  Serial.print(" %, Light: ");
  Serial.print(lightIntensity);
  Serial.println(" %");

  // Menampilkan data secara bergantian di LCD
  lcd.clear();

  if (displayState == 0) {
    lcd.setCursor(0, 0);
    lcd.print("Temp: ");
    lcd.print(celsius);
    lcd.print("C");
    lcd.setCursor(0, 1);
    lcd.print("Humidity: ");
    lcd.print(humidity);
    lcd.print("%");
    
  } else if (displayState == 1) {
    lcd.setCursor(0, 0);
    lcd.print("Light: ");
    lcd.print(lightIntensity);
    lcd.print("%");
  }

  displayState = (displayState + 1) % 3; // Looping tampilan
  delay(2000); // Delay sebelum berganti tampilan
}
